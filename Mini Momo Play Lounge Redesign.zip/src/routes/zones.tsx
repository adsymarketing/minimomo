import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { PageHeader, ZonesSection, VisitCTASection } from "@/components/site/sections";
import hero from "@/assets/hero-playlounge.jpg";

export const Route = createFileRoute("/zones")({
  head: () => ({
    meta: [
      { title: "Play Zones — MiniMomo Playlounge, Hubli" },
      {
        name: "description",
        content:
          "Explore all 10 play zones at MiniMomo Playlounge — ball pit, slides, climbers, spider web, ball blower, sand pit, and pretend-play garage, clinic, supermarket and cafe.",
      },
      { property: "og:title", content: "Play Zones — MiniMomo Playlounge" },
      {
        property: "og:description",
        content: "Ten little worlds inside one big indoor playlounge in Hubli.",
      },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: ZonesPage,
});

function ZonesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <PageHeader
        eyebrow="Play zones"
        title={
          <>
            Ten little worlds inside <span className="text-gradient-candy">one big one.</span>
          </>
        }
        subtitle="From the ball pit to the cupcake counter, every corner of MiniMomo is a fresh adventure designed to spark curiosity, creativity and confidence."
      />
      <ZonesSection id="all-zones" />
      <VisitCTASection />
      <Footer />
    </div>
  );
}
