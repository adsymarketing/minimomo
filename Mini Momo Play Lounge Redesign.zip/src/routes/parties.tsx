import { createFileRoute, Link } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { PageHeader, PartiesSection, VisitCTASection } from "@/components/site/sections";
import birthday from "@/assets/birthday.jpg";
import { Cake, Gift, Music, PartyPopper, Sparkles, Users, Camera, IceCream } from "lucide-react";

export const Route = createFileRoute("/parties")({
  head: () => ({
    meta: [
      { title: "Birthday Parties — MiniMomo Playlounge, Hubli" },
      {
        name: "description",
        content:
          "Host unforgettable kids' birthday parties at MiniMomo Playlounge, Hubli. Dedicated party area, themed decor, co-ordinator, food and games for 15–20 kids.",
      },
      { property: "og:title", content: "Birthday Parties at MiniMomo Playlounge" },
      {
        property: "og:description",
        content: "A dedicated party area, themed decor, and a co-ordinator who handles everything.",
      },
      { property: "og:image", content: birthday },
      { name: "twitter:image", content: birthday },
    ],
  }),
  component: PartiesPage,
});

const inclusions = [
  { icon: PartyPopper, title: "Exclusive party area", desc: "Your own decorated space plus full access to every play zone." },
  { icon: Cake, title: "Custom cake & menu", desc: "Pick a cake and snack menu the birthday star will actually eat." },
  { icon: Music, title: "Music & games", desc: "Themed games, music and a host to keep the energy high." },
  { icon: Gift, title: "Return gifts", desc: "Curated return-gift add-ons so you don't have to plan a thing." },
  { icon: Camera, title: "Photo moments", desc: "Photo-ready setups for the entrance, cake table and ball pit." },
  { icon: IceCream, title: "Food & drinks", desc: "Kid-approved menu options for guests of every age." },
];

function PartiesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <PageHeader
        eyebrow="Birthday parties"
        title={
          <>
            Throw a birthday they'll <span className="text-gradient-candy">remember forever.</span>
          </>
        }
        subtitle="Built for 15–20 kids with everything included — decor, food, games and a co-ordinator who runs the whole show so parents can finally sit down."
      />

      <PartiesSection id="party-overview" />

      <section className="mx-auto max-w-7xl px-6 py-20 md:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="font-display text-sm font-700 uppercase tracking-[0.25em] text-pink">
            What's included
          </span>
          <h2 className="mt-3 font-display text-4xl font-700 md:text-5xl">
            Everything for the perfect party
          </h2>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {inclusions.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-[1.75rem] border-2 border-border bg-card p-6 ring-tile">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-yellow text-foreground">
                <Icon size={20} />
              </span>
              <h3 className="mt-4 font-display text-lg font-700">{title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-20 md:px-8">
        <div className="rounded-[2.5rem] border-2 border-border bg-secondary/20 p-8 md:p-12">
          <div className="grid items-center gap-6 md:grid-cols-[1fr_auto]">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-foreground px-3 py-1 font-display text-xs font-700 uppercase tracking-widest text-background">
                <Sparkles size={14} /> How to book
              </span>
              <h2 className="mt-3 font-display text-3xl font-700 md:text-4xl">
                Pick your date, leave the rest to us.
              </h2>
              <p className="mt-3 max-w-xl text-muted-foreground">
                Tell us the headcount, theme and any food preferences. We'll send a quick
                quote and lock in your slot.
              </p>
              <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                <Users size={16} className="text-pink" /> 15–20 kids · Add-ons available for larger groups
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link to="/visit" className="rounded-full bg-primary px-6 py-3 font-display font-700 text-primary-foreground shadow-pop transition hover:-translate-y-0.5">
                Enquire now
              </Link>
              <a href="tel:+919663481122" className="rounded-full border-2 border-foreground px-6 py-3 font-display font-700 transition hover:bg-yellow/60">
                Call 9663 481 122
              </a>
            </div>
          </div>
        </div>
      </section>

      <VisitCTASection />
      <Footer />
    </div>
  );
}
