import { createFileRoute, Link } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import {
  ZonesSection,
  PricingSection,
  PartiesSection,
  TestimonialsSection,
  VisitCTASection,
} from "@/components/site/sections";
import logo from "@/assets/minimomo-logo.png.asset.json";
import hero from "@/assets/hero-playlounge.jpg";
import ballPit from "@/assets/ball-pit.jpg";
import { Shield, Sparkles, HeartHandshake, Smile, Star, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MiniMomo Playlounge — Indoor Soft Play for Kids in Hubli" },
      {
        name: "description",
        content:
          "Vibrant indoor soft play at Inorbit Mall, Hubli. Ball pits, slides, pretend play, birthdays. ₹290 / ₹450. Open 10 AM – 10 PM, all days.",
      },
      { property: "og:title", content: "MiniMomo Playlounge — Indoor Soft Play for Kids in Hubli" },
      {
        property: "og:description",
        content: "A joyful indoor playlounge where kids laugh, learn, and play safely every day.",
      },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="min-h-screen overflow-x-hidden bg-background">
      <Navbar />

      {/* HERO */}
      <section className="relative isolate overflow-hidden px-6 pb-24 pt-20 md:px-8 md:pb-32 md:pt-28">
        <div className="absolute right-[-15%] top-10 -z-10 h-[600px] w-[600px] rounded-full bg-sky/30 blur-3xl" aria-hidden />
        <div className="absolute -bottom-32 -left-32 -z-10 h-[500px] w-[500px] rounded-full bg-pink/30 blur-3xl" aria-hidden />

        <div className="mx-auto grid max-w-7xl items-center gap-16 md:grid-cols-2">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 rounded-full border border-yellow/60 bg-yellow/30 px-4 py-2 shadow-sm">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-coral opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-coral" />
              </span>
              <span className="font-display text-[10px] font-700 uppercase tracking-[0.2em] text-navy">
                Now open at Inorbit Mall, Hubli
              </span>
            </div>

            <h1 className="font-display text-6xl font-700 leading-[1.02] tracking-tight text-navy md:text-8xl">
              Where little
              <br />
              <span className="relative inline-block text-pink">
                hearts play
                <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 300 12" fill="none" aria-hidden>
                  <path d="M2 10C50 2 100 2 150 5C200 8 250 8 298 2" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                </svg>
              </span>
              <br />
              big.
            </h1>

            <p className="max-w-md text-xl leading-relaxed text-muted-foreground">
              MiniMomo Playlounge is a vibrant indoor soft-play world built by parents,
              for parents — where safety, hygiene and joy come standard.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link
                to="/visit"
                className="inline-flex items-center gap-2 rounded-3xl bg-pink px-8 py-4 font-display font-700 text-primary-foreground shadow-pop transition hover:-translate-y-1"
              >
                Plan your visit <ArrowRight size={18} />
              </Link>
              <Link
                to="/zones"
                className="inline-flex items-center gap-2 rounded-3xl border-2 border-border bg-background px-8 py-4 font-display font-700 text-navy transition hover:border-sky"
              >
                Explore zones
              </Link>
            </div>

            <div className="flex items-center gap-4 pt-2">
              <div className="flex -space-x-3">
                {["bg-pink/40", "bg-sky/50", "bg-yellow/60", "bg-mint/50"].map((c) => (
                  <span key={c} className={`h-11 w-11 rounded-full border-2 border-background ${c}`} />
                ))}
              </div>
              <div>
                <div className="flex items-center gap-0.5 text-yellow">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={14} className="fill-yellow" />
                  ))}
                  <span className="ml-1 font-display text-sm font-700 text-navy">4.7</span>
                </div>
                <p className="text-xs text-muted-foreground">357 Google reviews · Hubli</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 -z-10 rounded-[3.5rem] bg-gradient-to-tr from-pink/30 to-sky/40 opacity-70 blur-2xl [transform:rotate(3deg)]" aria-hidden />
            <div className="relative overflow-hidden rounded-[3rem] border-8 border-background shadow-3xl [transform:rotate(-2deg)]">
              <img
                src={hero}
                alt="MiniMomo Playlounge interior with ball pit and slides"
                width={1600}
                height={1100}
                className="aspect-[4/5] w-full object-cover"
              />
              <div className="absolute bottom-6 right-6 grid h-28 w-28 animate-wiggle place-items-center rounded-full bg-background p-2 shadow-soft md:h-32 md:w-32">
                <img
                  src={logo.url}
                  alt=""
                  aria-hidden
                  className="h-full w-full rounded-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST STRIP */}
      <section className="border-y border-border/60 bg-navy/[0.03]">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-6 py-10 md:grid-cols-4 md:px-8">
          {[
            { icon: Shield, label: "Safety-first design", c: "pink" },
            { icon: Sparkles, label: "Sanitised toys", c: "sky" },
            { icon: HeartHandshake, label: "Built by parents", c: "yellow" },
            { icon: Smile, label: "Trained play crew", c: "mint" },
          ].map(({ icon: Icon, label, c }) => (
            <div key={label} className="flex items-center gap-3">
              <span
                className="grid h-12 w-12 place-items-center rounded-2xl text-navy"
                style={{ background: `var(--${c})` }}
              >
                <Icon size={18} />
              </span>
              <span className="font-display font-600 text-navy">{label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ABOUT */}
      <section className="mx-auto max-w-7xl px-6 py-24 md:px-8 md:py-32">
        <div className="grid items-center gap-14 md:grid-cols-2">
          <div className="relative">
            <div className="absolute -inset-3 -z-10 rounded-[3rem] bg-gradient-to-br from-yellow/60 to-coral/30 [transform:rotate(2deg)]" aria-hidden />
            <img
              src={ballPit}
              alt="Close up of pastel ball pit"
              width={900}
              height={1200}
              loading="lazy"
              className="aspect-[4/5] w-full rounded-[2.5rem] border-8 border-background object-cover shadow-soft"
            />
          </div>
          <div>
            <span className="font-display text-xs font-700 uppercase tracking-[0.25em] text-pink">
              Our story
            </span>
            <h2 className="mt-4 font-display text-4xl font-700 leading-[1.05] text-navy md:text-6xl">
              A joyful indoor playlounge where kids
              <span className="text-pink"> laugh, learn and play safely</span> every day.
            </h2>
            <p className="mt-6 text-lg text-muted-foreground">
              At MiniMomo Playlounge we are redefining playtime into something truly
              extraordinary. Our vibrant soft-play world is thoughtfully designed to
              inspire curiosity, creativity and confidence in every child — whether
              it's an exciting weekend playdate, a memorable birthday celebration or a
              quiet moment of family connection.
            </p>
            <p className="mt-4 text-lg text-muted-foreground">
              Every climber, cushion and cupcake counter is built around three simple
              promises: <span className="font-700 text-navy">safety, hygiene and joy.</span>
            </p>
            <Link
              to="/about"
              className="mt-7 inline-flex items-center gap-2 rounded-3xl bg-navy px-7 py-4 font-display font-700 text-background transition hover:-translate-y-0.5"
            >
              Read our story <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      <ZonesSection />
      <PricingSection />
      <PartiesSection />
      <TestimonialsSection />
      <VisitCTASection />

      <Footer />
    </div>
  );
}
