import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { PageHeader, PricingSection, VisitCTASection } from "@/components/site/sections";
import hero from "@/assets/hero-playlounge.jpg";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — MiniMomo Playlounge, Hubli" },
      {
        name: "description",
        content:
          "MiniMomo Playlounge pricing: ₹290 on weekdays, ₹450 on weekends per child. Parents free. Party packages for 15–20 kids. Socks compulsory (₹70/pair).",
      },
      { property: "og:title", content: "Pricing — MiniMomo Playlounge" },
      {
        property: "og:description",
        content: "Simple, kid-friendly pricing. Walk-in any day, all day.",
      },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: PricingPage,
});

function PricingPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <PageHeader
        eyebrow="Pricing"
        title={
          <>
            Simple, <span className="text-gradient-candy">kid-friendly</span> pricing.
          </>
        }
        subtitle="Unlimited play across every zone, all day. Parents always free."
      />
      <PricingSection id="all-pricing" />
      <VisitCTASection />
      <Footer />
    </div>
  );
}
