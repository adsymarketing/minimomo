import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Twitter } from "lucide-react";
import hero from "@/assets/hero-playlounge.jpg";
import { useState } from "react";

export const Route = createFileRoute("/visit")({
  head: () => ({
    meta: [
      { title: "Visit Us — MiniMomo Playlounge, Inorbit Mall, Hubli" },
      {
        name: "description",
        content:
          "Plan your visit to MiniMomo Playlounge — Second Floor, SFO7, Inorbit Mall, Hubli. Open 10 AM – 10 PM, all days. Call 9663 481 122.",
      },
      { property: "og:title", content: "Visit MiniMomo Playlounge in Hubli" },
      {
        property: "og:description",
        content: "Directions, timings and contact details for MiniMomo Playlounge at Inorbit Mall, Hubli.",
      },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: VisitPage,
});

function VisitPage() {
  const [sent, setSent] = useState(false);
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-[oklch(0.95_0.06_220)] to-background" aria-hidden />
        <div className="absolute inset-0 -z-10 bg-confetti opacity-40" aria-hidden />
        <div className="mx-auto max-w-7xl px-6 py-16 md:px-8 md:py-24">
          <span className="font-display text-sm font-700 uppercase tracking-[0.25em] text-pink">
            Plan your visit
          </span>
          <h1 className="mt-3 font-display text-5xl font-700 leading-[0.95] md:text-7xl">
            Come and say <span className="text-gradient-candy">hi!</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg text-muted-foreground">
            We're tucked away on the second floor of Inorbit Mall, Hubli — easy to find,
            even easier to fall in love with.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-6 px-6 md:grid-cols-2 md:px-8 lg:grid-cols-4">
        {[
          { icon: Phone, title: "Call us", lines: ["9663 481 122"], href: "tel:+919663481122" },
          { icon: Mail, title: "Mail us", lines: ["minimomoplaylounge@gmail.com"], href: "mailto:minimomoplaylounge@gmail.com" },
          { icon: MapPin, title: "Location", lines: ["Second Floor, SFO7", "Inorbit Mall, Hubli"] },
          { icon: Clock, title: "Timings", lines: ["10 AM – 10 PM", "Open all days"] },
        ].map(({ icon: Icon, title, lines, href }) => {
          const content = (
            <div className="flex h-full flex-col rounded-[2rem] border-2 border-border bg-card p-6 ring-tile transition hover:-translate-y-1">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-pink text-primary-foreground">
                <Icon size={20} />
              </span>
              <h3 className="mt-4 font-display text-lg font-700">{title}</h3>
              <div className="mt-1 text-muted-foreground">
                {lines.map((l) => <div key={l}>{l}</div>)}
              </div>
            </div>
          );
          return href ? (
            <a key={title} href={href} className="block h-full">{content}</a>
          ) : (
            <div key={title}>{content}</div>
          );
        })}
      </section>

      <section className="mx-auto grid max-w-7xl gap-8 px-6 py-16 md:grid-cols-5 md:px-8 md:py-24">
        <div className="md:col-span-3">
          <h2 className="font-display text-3xl font-700 md:text-4xl">Find us on the map</h2>
          <p className="mt-2 text-muted-foreground">Inorbit Mall, Gokul Road, Hubballi, Karnataka.</p>
          <div className="mt-5 overflow-hidden rounded-[2rem] border-4 border-background shadow-pop">
            <iframe
              title="MiniMomo Playlounge location"
              src="https://www.google.com/maps?q=Inorbit+Mall+Hubli&output=embed"
              className="h-[420px] w-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>

        <div className="md:col-span-2">
          <h2 className="font-display text-3xl font-700 md:text-4xl">Drop us a note</h2>
          <p className="mt-2 text-muted-foreground">Birthdays, group visits, partnerships — we'd love to hear from you.</p>
          <form
            className="mt-5 space-y-3 rounded-[2rem] border-2 border-border bg-card p-6 ring-tile"
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
            }}
          >
            <div>
              <label className="font-display text-sm font-700">Name</label>
              <input required type="text" className="mt-1 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 outline-none focus:border-pink" />
            </div>
            <div>
              <label className="font-display text-sm font-700">Email</label>
              <input required type="email" className="mt-1 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 outline-none focus:border-pink" />
            </div>
            <div>
              <label className="font-display text-sm font-700">Message</label>
              <textarea required rows={4} className="mt-1 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 outline-none focus:border-pink" />
            </div>
            <button
              type="submit"
              className="w-full rounded-full bg-primary px-6 py-3 font-display font-700 text-primary-foreground shadow-pop transition hover:-translate-y-0.5"
            >
              {sent ? "Thanks! We'll be in touch 💛" : "Send message"}
            </button>
          </form>

          <div className="mt-6">
            <h3 className="font-display text-base font-700">Follow our social</h3>
            <div className="mt-3 flex gap-3">
              <a aria-label="Instagram" href="https://www.instagram.com/minimomo_playlounge/" target="_blank" rel="noreferrer" className="rounded-full bg-pink p-3 text-primary-foreground transition hover:-translate-y-0.5"><Instagram size={18} /></a>
              <a aria-label="Facebook" href="https://www.facebook.com/share/1Fhh7UcEBd/" target="_blank" rel="noreferrer" className="rounded-full bg-secondary p-3 text-primary-foreground transition hover:-translate-y-0.5"><Facebook size={18} /></a>
              <a aria-label="Twitter" href="https://x.com/MiniMomo_PL" target="_blank" rel="noreferrer" className="rounded-full bg-foreground p-3 text-background transition hover:-translate-y-0.5"><Twitter size={18} /></a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
